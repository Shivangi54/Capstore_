package com.cg.capstore.repo;

import java.util.List;

import com.cg.capstore.bean.Image;

public interface ICapstoreAdminRepo {
	public void addProduct(String productName,String productSize,int productQuantity,String productCategory,double productPrice,double productDiscount,List<Image> productImage);
}
