package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.bean.Image;
import com.cg.capstore.repo.ICapstoreAdminRepo;

@Transactional
@Service("service")
public class CapstoreAdminServiceImpl implements ICapstoreAdminService{
	@Autowired
	ICapstoreAdminRepo repo;
	@Override
	public void addProduct(String productName,String productSize,int productQuantity,String productCategory,double productPrice,double productDiscount,List<Image> productImage) {
		repo.addProduct(productName, productSize, productQuantity, productCategory, productPrice, productDiscount, productImage);
		
	}

}
