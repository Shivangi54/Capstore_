package com.cg.capstore.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Image;
import com.cg.capstore.bean.Product;


@Repository("repo")
public class CapstoreAdminRepoImpl implements ICapstoreAdminRepo{
	@PersistenceContext
	EntityManager entityManager;
	
	 CapstoreAdminRepoImpl capstoreDao;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public void addProduct(String productName,String productSize,int productQuantity,String productCategory,double productPrice,double productDiscount,List<Image> productImage) {
		Product product=new Product();
		product.setName(productName);
		product.setSize(productSize);
		product.setQuantity(productQuantity);
		product.setProdCategory(productCategory);
		product.setPrice(productPrice);
		product.setProdDiscount(productDiscount);
		product.setProdImages(productImage);
	}

}
