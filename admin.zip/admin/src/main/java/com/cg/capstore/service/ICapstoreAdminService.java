package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.bean.Image;

public interface ICapstoreAdminService {
	public void addProduct(String productName,String productSize,int productQuantity,String productCategory,double productPrice,double productDiscount,List<Image> productImage);
}
