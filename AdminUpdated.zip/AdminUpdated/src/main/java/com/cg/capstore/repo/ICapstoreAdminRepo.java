package com.cg.capstore.repo;

import com.cg.capstore.bean.Image;
import com.cg.capstore.bean.Product;


public interface ICapstoreAdminRepo {
	public String addProduct(Product product);
	public void addProductImage(String productId, Image image);
}
