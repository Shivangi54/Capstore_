package com.cg.capstore.repo;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Image;
import com.cg.capstore.bean.Product;


@Repository("repo")
public class CapstoreAdminRepoImpl implements ICapstoreAdminRepo{
	@PersistenceContext
	EntityManager entityManager;
	
	 CapstoreAdminRepoImpl capstoreDao;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Override
	public String addProduct(Product product) {
		Random random=new Random();
		 String productId="P#"+Integer.toString(random.nextInt(10000));
		product.setProdId(productId);
		System.out.println(product.getProdId());
	    System.out.println(product);
		entityManager.persist(product);
		return productId;
	}
	@Override
	public void addProductImage(String productId, Image image) {
		Random random=new Random();
		String imageId="I#"+Integer.toString(random.nextInt(10000));
		image.setImageId(imageId);
		List<Image> imageList=new ArrayList<Image>();
		imageList.add(image);
		Product product=entityManager.find(Product.class, productId);
		product.setProdImages(imageList);
		List<Product> productList=new ArrayList<Product>();
		productList.add(product);
		image.setProductImg(productList);
		entityManager.persist(image);
		entityManager.persist(product);
		entityManager.merge(image);
		
	}

}
