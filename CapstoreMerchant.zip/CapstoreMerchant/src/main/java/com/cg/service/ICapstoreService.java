package com.cg.service;

import java.util.List;

import com.cg.bean.Cart_Product;

public interface ICapstoreService {
	public List<Cart_Product> generateInvoice(String cart_id);
}
