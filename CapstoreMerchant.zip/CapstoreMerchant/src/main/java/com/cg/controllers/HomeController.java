package com.cg.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Cart_Product;
import com.cg.bean.Product;
import com.cg.service.ICapstoreService;

@RestController
public class HomeController {
	@Autowired
	ICapstoreService service;
	
	@RequestMapping("/")
	public ModelAndView display() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Cart");
		return mv;
	}
	
	@RequestMapping("/Invoice")
	public ModelAndView invoice(@RequestParam("cartId") String cart_id,Model model){
		double totalPrice=0;
		List<Cart_Product> cart = service.generateInvoice(cart_id);
		List<Product> productList=new ArrayList<Product>();
		for(int i=0;i<cart.size();i++) {
			productList.add(cart.get(i).getProduct());
			totalPrice+=productList.get(i).getPrice();
		}
		model.addAttribute("list","productList");
		model.addAttribute("totalPrice","totalPrice");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Invoice");
		return mv;
	}
	
	
}
