package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.bean.Cart_Product;
import com.cg.bean.Product;
@Repository("repo")
public class CapstoreDaoImpl implements ICapstoreDao{
	@PersistenceContext
	EntityManager entityManager;
	
	 CapstoreDaoImpl capstoreDao;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	Product product=new Product(); 
    Cart_Product cart=new Cart_Product();

	@Override
	public List<Cart_Product> generateInvoice(String cart_id) {
			List<Cart_Product> cart= (List<Cart_Product>) entityManager.find(Cart_Product.class, cart_id);
			List<Product> productList=new ArrayList<Product>();
			for(int i=0;i<cart.size();i++) {
				productList.add(cart.get(i).getProduct());
			}
			for(int i=0;i<productList.size();i++) {
				double discount=productList.get(i).getDiscount();
				if(discount!=0) {
					double price=productList.get(i).getPrice();
					productList.get(i).setPrice(price-(price*discount/100));
				}
			}
			return cart;
	}

}
