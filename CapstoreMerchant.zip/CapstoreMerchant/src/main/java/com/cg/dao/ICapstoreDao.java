package com.cg.dao;

import java.util.List;

import com.cg.bean.Cart_Product;

public interface ICapstoreDao {

	public List<Cart_Product> generateInvoice(String cart_id);
}
