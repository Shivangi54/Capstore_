package com.cg.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class Cart_Product {
	
	@Id
	private String cart_id;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="prod_id")
	private Product product;
	
	public Product getProduct() {
		return product;
	}
	public String getCart_id() {
		return cart_id;
	}
	public void setCart_id(String cart_id) {
		this.cart_id = cart_id;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Cart_Product(String cart_id, Product product) {
		super();
		this.cart_id = cart_id;
		this.product = product;
	}
	public Cart_Product() {
		super();
	}
	@Override
	public String toString() {
		return "Cart_Product [cart_id=" + cart_id + ", product=" + product + "]";
	}
	
}
