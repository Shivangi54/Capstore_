package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Product {
	@Id
	private String prod_id;
	private String name;
	private String sizes;
	private int initial_quantity;
	private int available_quantity;
	private double price;
	private double rating;
	
	private String product_category;
	private double discount;
	private String prod_coupon;
	
	public Product() {
		super();
		
	}

	public Product(String prod_id, String name, String sizes, double price, double discount) {
		super();
		this.prod_id = prod_id;
		this.name = name;
		this.sizes = sizes;
		this.price = price;
		this.discount = discount;
	}

	public String getProd_id() {
		return prod_id;
	}

	public void setProd_id(String prod_id) {
		this.prod_id = prod_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSizes() {
		return sizes;
	}

	public void setSizes(String sizes) {
		this.sizes = sizes;
	}

	public int getInitial_quantity() {
		return initial_quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "Product [prod_id=" + prod_id + ", name=" + name + ", sizes=" + sizes + ", price=" + price
				+ ", discount=" + discount + "]";
	}
	 
}
